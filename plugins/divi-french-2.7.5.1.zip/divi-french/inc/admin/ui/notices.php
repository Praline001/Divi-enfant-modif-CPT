<?php
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

/**
 * Add admin notices
 *
 * @since 1.2
 */
add_action( 'admin_notices', 'divi_french_admin_notices' );
function divi_french_admin_notices() {

	$notice = get_transient( '_divi_french_license_error' );
	$key = get_option( 'divi_french_license_key' );

	if ( $notice !== false ) {

		switch ( $notice ) {

			case 'expired' :
				$message_class = 'error';
				$message = sprintf(
					__( 'Your license key has expired. Please <a href="%s" target="_blank" title="Renew your license key">renew your license key</a>.', 'divi-french' ),
					DIVI_FRENCH_STORE_URL.'/commander/?edd_license_key=' . $key
				);
		  break;

			case 'missing' :
				$message_class = 'error';
				$message = sprintf(
					__( 'Invalid license. Please <a href="%s" target="_blank" title="Visit account page">visit your account page</a> and verify it.', 'divi-french' ),
					DIVI_FRENCH_STORE_URL.'/votre-compte'
				);
		  break;

			case 'invalid' :
			case 'site_inactive' :
				$message_class = 'error';
				$message = sprintf( __( 'There was a problem activating your license key, please try again or contact support. Error code: %s', 'divi-french' ), $notice );
		  break;

			case 'item_name_mismatch' :
				$message_class = 'error';
				$message = __( 'This license does not belong to the product you have entered it for.', 'divi-french' );
		  break;

			case 'no_activations_left':
				$message_class = 'error';
				$message = sprintf( __( 'Your license key has reached its activation limit. <a href="%s">View possible upgrades</a> now.', 'divi-french' ), DIVI_FRENCH_STORE_URL.'/votre-compte' );
		  break;

		}

		if ( ! empty( $message ) ) { ?>

  		<div class="<?php echo $message_class; ?> notice is-dismissible">
  		    <p><?php echo DIVI_FRENCH_ITEM_NICE_NAME.' : ' .$message; ?></p>
        </div>

  	<?php }
	}

}

/**
 * Return notices for AJAX
 *
 * @since 1.2
 */
function divi_french_ajax_notices() {

	$notice = get_transient( '_divi_french_license_error' );
	$key = get_option( 'divi_french_license_key' );

	if ( $notice !== false ) {

		switch ( $notice ) {

			case 'expired' :
				$message = sprintf(
					__( 'Your license key has expired. Please <a href="%s" target="_blank" title="Renew your license key">renew your license key</a>.', 'divi-french' ),
					DIVI_FRENCH_STORE_URL.'/commander/?edd_license_key=' . $key
				);
		  break;

			case 'missing' :
				$message = sprintf(
					__( 'Invalid license. Please <a href="%s" target="_blank" title="Visit account page">visit your account page</a> and verify it.', 'divi-french' ),
					DIVI_FRENCH_STORE_URL.'/votre-compte'
				);
		  break;

			case 'invalid' :
			case 'site_inactive' :
				$message = sprintf( __( 'There was a problem activating your license key, please try again or contact support. Error code: %s', 'divi-french' ), $notice );
		  break;

			case 'item_name_mismatch' :
				$message = __( 'This license does not belong to the product you have entered it for.', 'divi-french' );
		  break;

			case 'no_activations_left':
				$message = sprintf( __( 'Your license key has reached its activation limit. <a href="%s">View possible upgrades</a> now.', 'divi-french' ), DIVI_FRENCH_STORE_URL.'/votre-compte' );
		  break;

		}

		return $message;

	}

}
