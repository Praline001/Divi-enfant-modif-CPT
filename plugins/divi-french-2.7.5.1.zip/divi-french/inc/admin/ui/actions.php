<?php
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

/**
 * Ouput Activate license button
 *
 * @since 1.2
 */
function divi_french_action_add_license() {
	?>

	<div><button type="button" id="divi_french_license_activate" class="button-secondary"> <?php _e( 'Activate License', 'divi-french' ); ?></button><span id="spinner-divi-french" class="spinner"></span></div>

<?php }

/**
 * Ouput Deactivate license button and license informations
 *
 * @since 1.2
 */
function divi_french_action_remove_license( $expires ) {

	$now        = current_time( 'timestamp' );
	$expiration = strtotime( $expires, current_time( 'timestamp' ) );
	$key = get_option( 'divi_french_license_key' );
	$license = get_transient( '_divi_french_license_data' );

	if ( 'lifetime' === $expires ) {
		$expiration_message = __( 'License key never expires.', 'divi-french' );
	} elseif ( $expiration > $now && $expiration - $now < ( DAY_IN_SECONDS * 30 ) ) {
		$expiration_message = sprintf(
			__( 'Your license key expires soon! It expires on %s. <a href="%s" target="_blank" title="Renew license">Renew your license key</a>.', 'divi-french' ),
			date_i18n( 'j F Y', strtotime( $expires, current_time( 'timestamp' ) ) ),
			DIVI_FRENCH_STORE_URL.'/commander/?edd_license_key=' . $key
		);
	} else {
		$expiration_message = sprintf(
			__( 'Your license key expires on %s.', 'divi-french' ),
			date_i18n( 'j F Y', strtotime( $expires, current_time( 'timestamp' ) ) )
		);
	}

	?>
    <div class="fxb-license-information">
		<div><span class="fxb-success dashicons dashicons-yes"></span> <?php _e( 'License active', 'divi-french' ); ?></div>
		<div><span class="dashicons dashicons-backup"></span> <?php echo $expiration_message; ?></strong></div>
		<div><button type="button" id="divi_french_license_deactivate" class="button-secondary"><span class="fxb-vam dashicons dashicons-no"></span> <?php _e( 'Deactivate License', 'divi-french' ); ?></button><span id="spinner-divi-french" class="spinner"></span></div>
    </div>

<?php }
