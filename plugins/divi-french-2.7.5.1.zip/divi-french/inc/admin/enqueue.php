<?php
defined( 'ABSPATH' ) or die( 'Cheatin\' uh?' );

/**
 * Load admin scripts
 *
 * @since 1.2
 */
function divi_french_load_admin_script() {

	$translation_array = array(
		'license_deactivate' => DIVI_FRENCH_ITEM_NICE_NAME.' : '.__( 'License deactivate', 'divi-french' ),
	'ajax_fail' => __( 'Please try again soon.', 'divi-french' ),
	);

	wp_enqueue_script( 'divi-french-script', DIVI_FRENCH_ASSETS_JS_URL . 'script.js', array( 'jquery' ), '1.0.0', false );

	wp_localize_script( 'divi-french-script', 'divi_french_ajax', array(
		'ajaxurl' => admin_url( 'admin-ajax.php' ),
		'license_deactivate' => $translation_array,
		'ajax_fail' => $translation_array,
		'divi_french_nonce' => wp_create_nonce( 'divi-french-nonce' ),
	) );

	wp_register_style( 'divi-french-css', DIVI_FRENCH_ASSETS_CSS_URL . 'style.css', false, '1.0.0' );
	wp_enqueue_style( 'divi-french-css' );

}
add_action( 'admin_enqueue_scripts', 'divi_french_load_admin_script' );
