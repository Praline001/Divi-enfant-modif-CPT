jQuery(document).ready(function($) {

	$('#divi_french_license_activate').live( "click", function() {

			$.ajax({
				type: "POST",
				url: divi_french_ajax.ajaxurl,
				data: {
					'action': 'divi_french_activate_license',
					'divi_french_nonce': divi_french_ajax.divi_french_nonce,
				},
				beforeSend: function(reponse) {
					$('#spinner-divi-french').addClass('is-active');
				},
				success: function(response) {
					$('#spinner-divi-french').removeClass('is-active');
					$('#divi-french-reponse').html(response);
				},
				fail: function() {
					$('h1').after('<div class="error"><p>' + divi_french_ajax.ajax_fail.ajax_fail + '</p></div>');
				}

			});

	});

	$('#divi_french_license_deactivate').live( "click", function() {

		$.ajax({
			type: "POST",
			url: divi_french_ajax.ajaxurl,
			data: {
				'action': 'divi_french_deactivate_license',
				'divi_french_nonce': divi_french_ajax.divi_french_nonce,
			},
			beforeSend: function(reponse) {
				$('#spinner-divi-french').addClass('is-active');
			},
			success: function(response) {
				$('#spinner-divi-french').removeClass('is-active');
				$('#divi-french-reponse').html(response);
				$('#divi_french_license_key').val('');
				$('h1').after('<div class="updated notice is-dismissible"><p>' + divi_french_ajax.license_deactivate.license_deactivate + '</p></div>');
			},
			fail: function() {
				$('h1').after('<div class="error"><p>' + divi_french_ajax.ajax_fail.ajax_fail + '</p></div>');
			}
		});

	});

});
