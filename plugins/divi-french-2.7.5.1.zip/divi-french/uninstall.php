<?php
// If uninstall not called from WordPress exit.
defined( 'WP_UNINSTALL_PLUGIN' ) or die( 'Cheatin&#8217; uh?' );

// Delete plugin transients
delete_transient( '_divi_french_license_data' );
delete_transient( '_divi_french_license_error' );

// Delete plugin options
delete_option( 'divi_french_license_key' );
delete_option( 'divi_french_license_status' );
