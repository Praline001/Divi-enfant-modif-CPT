<?php
/**
 * Plugin Name:      Divi French
 * Plugin URI:      https://fxbenard.com/traductions/divi-french
 * Description:      French Translations for Divi
 * Version:      2.7.5.1
 * Author:      FX Bénard
 * Author URI:      https://fxbenard.com
 * Text Domain:      divi-french
 * Requires at least: 4.1
 * Tested up to: 4.5.2
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the GNU
 * General Public License version 2, as published by the Free Software Foundation. You may NOT assume
 * that you can use any other version of the GPL.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @package         Divi French
 * @author          FX Bénard <fx@fxbenard.com>
 * @copyright       Copyright (c) 2016 FX Bénard
 * @license         http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

// Divi French defines.
define( 'DIVI_FRENCH_VERSION', '2.7.5.1' );
define( 'DIVI_FRENCH_STORE_URL', 'https://fxbenard.com' ); // Store URL for API call.
define( 'DIVI_FRENCH_ITEM_NAME', 'Divi French' ); // Item Name for API call.
define( 'DIVI_FRENCH_ITEM_NICE_NAME', 'Divi French' ); // Item Nice Name.
define( 'DIVI_FRENCH_FILE', __FILE__ );
define( 'DIVI_FRENCH_URL', plugin_dir_url( DIVI_FRENCH_FILE ) );
define( 'DIVI_FRENCH_PATH', realpath( plugin_dir_path( DIVI_FRENCH_FILE ) ) . '/' );
define( 'DIVI_FRENCH_INC_PATH', realpath( DIVI_FRENCH_PATH . 'inc' ) . '/' );
define( 'DIVI_FRENCH_3RDPARTY_PATH', realpath( DIVI_FRENCH_INC_PATH . '3rd-party' ) . '/' );
define( 'DIVI_FRENCH_CLASSES_PATH', realpath( DIVI_FRENCH_INC_PATH . 'classes' ) . '/' );
define( 'DIVI_FRENCH_ADMIN_PATH', realpath( DIVI_FRENCH_INC_PATH . 'admin' ) . '/' );
define( 'DIVI_FRENCH_ADMIN_UI_PATH', realpath( DIVI_FRENCH_ADMIN_PATH . 'ui' ) . '/' );
define( 'DIVI_FRENCH_API_PATH', realpath( DIVI_FRENCH_INC_PATH . 'api' ) . '/' );
define( 'DIVI_FRENCH_FUNCTIONS_PATH', realpath( DIVI_FRENCH_INC_PATH . 'functions' ) . '/' );
define( 'DIVI_FRENCH_ASSETS_URL',  DIVI_FRENCH_URL . 'assets/' );
define( 'DIVI_FRENCH_ASSETS_JS_URL', DIVI_FRENCH_ASSETS_URL . 'js/' );
define( 'DIVI_FRENCH_ASSETS_CSS_URL', DIVI_FRENCH_ASSETS_URL . 'css/' );
define( 'DIVI_FRENCH_ASSETS_IMG_URL', DIVI_FRENCH_ASSETS_URL . 'img/' );

/**
 * Tell WP what to do when plugin is loaded
 *
 * @since 1.2
 */
function divi_french_init() {

	if ( is_admin() ) {

		if ( ! class_exists( 'DIVI_FRENCH_Plugin_Updater' ) ) {
				require( DIVI_FRENCH_CLASSES_PATH . 'DIVI_FRENCH_Plugin_Updater.php' );
		}

		require( DIVI_FRENCH_ADMIN_PATH . 'options.php' );
		require( DIVI_FRENCH_ADMIN_PATH . 'enqueue.php' );
		require( DIVI_FRENCH_ADMIN_UI_PATH . 'options.php' );
		require( DIVI_FRENCH_ADMIN_UI_PATH . 'actions.php' );
		require( DIVI_FRENCH_ADMIN_UI_PATH . 'notices.php' );
		require( DIVI_FRENCH_API_PATH . 'edd-software-licensing.php' );
		require( DIVI_FRENCH_FUNCTIONS_PATH . 'license.php' );

	}

}
add_action( 'plugins_loaded', 'divi_french_init' );


/**
 * Setup the updater
 *
 * @since 1.0
 */
function divi_french_plugin_updater() {

		$license_key = trim( get_option( 'divi_french_license_key' ) );

		// Setup the updater.
		$edd_updater = new DIVI_FRENCH_Plugin_Updater( DIVI_FRENCH_STORE_URL, __FILE__, array(
			'version' 	=> DIVI_FRENCH_VERSION,
			'license' 	=> $license_key, 		// License key (used get_option above to retrieve from DB).
			'item_name' => DIVI_FRENCH_ITEM_NAME,
			'author' 	=> 'fxbenard',
			)
		);

}
add_action( 'admin_init', 'divi_french_plugin_updater', 0 );

/**
 * Load Divi French themes textdomain function
 * Thanks to @grappler for his help
 */
function divi_french_themes_load_textdomain() {

	$domains = array(
		'Divi',
		'et_builder',
		'et-core',
		);

	foreach ( $domains as $domain ) {
		if ( $loaded = load_theme_textdomain( $domain, WP_LANG_DIR . '/themes' ) ) {
			$trad_location = 'languages_dir_themes';
		} else {
			$loaded = load_theme_textdomain( $domain, plugin_dir_path( __FILE__ ) . 'languages/' . $domain . '/' );
		}
	}

	if ( in_array( 'et_builder', $domains ) ) {
		require( DIVI_FRENCH_3RDPARTY_PATH . 'et-builder.php' );
	}

}
add_action( 'after_setup_theme', 'divi_french_themes_load_textdomain', 10 );


/**
 * Load Divi French plugins textdomain function
 * Thanks to @grappler for his help
 */
function divi_french_load_plugin_textdomain() {
	$domains = array(
		'divi-french',
	);
	foreach ( $domains as $domain ) {
		$locale = apply_filters( 'plugin_locale', get_locale(), $domain );
		if ( $loaded = load_textdomain( $domain, trailingslashit( WP_LANG_DIR ) . 'fx-trads/' . $domain . '/' . $domain . '-' . $locale . '.mo' ) ) {
				$trad_location = 'languages_dir_fxtrads';
		} elseif ( $loaded = load_textdomain( $domain, trailingslashit( WP_LANG_DIR ) . $domain . '-' . $locale . '.mo' ) ) {
				$trad_location = 'languages_dir';
		} else {
			load_plugin_textdomain( $domain, false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' . $domain . '/' );
		}
	}
}
add_action( 'plugins_loaded', 'divi_french_load_plugin_textdomain', 0 );
